
<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div id="container">
	<div class="row">
		<div class="col-md-5 offset-md-7">
			<div class="login-box">
				<div class="row">
					<div class="col-md-12 text-center">
						<div style="text-align: center;">
							<img style="width:80%; margin:auto;" src="<?php echo e(asset('img/logo_pp.png')); ?>">
						</div>
						<br>
						<h4 class="text-white font-weight-bold">FORMULARIO DE ACCESO</h4>
						<form action="<?php echo e(url('auth/')); ?>" method="POST" autocomplete="off">
                          <?php echo csrf_field(); ?>
                          <input style="display:none">
                          <input type="text" style="display:none">
                          <input autocomplete="false" name="hidden" type="text" style="display:none;">
                          <div class="form-group">
						    <label class="text-light">Usuario: </label>
						    <input required type="text" class="form-control form-control-lg" name="uuo" id="uuo" placeholder="Escriba el nombre de usuario." autocomplete="false" autofocus>
							<?php $__errorArgs = ['uuo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								<?php echo e($message); ?>

							</div>											
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						  </div>
						  <div class="form-group">
						    <label class="text-light">Contraseña: </label>
						    <input required type="password" class="form-control form-control-lg" name="ovc" id="ovc" placeholder="Escriba la contraseña" autocomplete="false">
							<?php $__errorArgs = ['ovc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								<?php echo e($message); ?>

							</div>											
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						  </div>
						  <?php echo RecaptchaV3::initJs(); ?>

						  <?php echo RecaptchaV3::field('captcha'); ?>


						  <button type="submit" class="btn btn-lg btn-block btn-info">
								<i class="fa fa-lock"></i>
								Acceder
							</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.noautenticado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TESIS - PROYECTOS - CONTRATOS\sma\sma-web\resources\views/publico/login.blade.php ENDPATH**/ ?>