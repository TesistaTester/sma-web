
<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div class="col-md-10 content-pane">
		<h3 class="title-header" style="text-transform: uppercase;">
			<i class="fa fa-plus"></i>
			<?php echo e($titulo); ?>

			<a href="<?php echo e(url('aeronaves/'.Crypt::encryptString($aeronave->ae_id).'/componentes/'.Crypt::encryptString($componente->com_id).'/mantenimientos/'.Crypt::encryptString($mantenimiento->cma_id).'/inspecciones')); ?>" title="Volver a lista de inspecciones" data-placement="bottom" class="btn btn-sm btn-secondary float-right" style="margin-left:10px;"><i class="fa fa-angle-double-left"></i> ATRÁS</a>
		</h3>

		<div class="row">
			<div class="col-md-12">
				<!-- inicio card  -->
				<div class="card">
					<div class="row no-gutters">
						<div class="col-md-12">
							<div class="card-body">

								<div class="alert alert-secondary">
									<div class="row">
										<div class="col-md-6">
											<h4 class="">
												<span class="text-info">COMPONENTE:</span> <?php echo e($componente->com_descripcion); ?> 
											</h4>
											<h4>
												<span class="text-info">SN:</span> <?php echo e($componente->com_serial_number); ?>

											</h4>        
											<h4>
												<span class="text-info">MANTENIMIENTO:</span> <?php echo e($mantenimiento->cma_nombre_tipo_inspeccion); ?>

											</h4>        
										</div>
										<div class="col-md-6">
											<h4 class="">
												<span class="text-info">TIPO COMPONENTE:</span> 
												
												<?php if($componente->com_tipo_componente == 1): ?> 
												SLL Scrap
												<?php endif; ?>
												
												<?php if($componente->com_tipo_componente == 2): ?>
												SLL Overhaul
												<?php endif; ?>
												
												<?php if($componente->com_tipo_componente == 3): ?>
												Shelf Life
												<?php endif; ?>
												
												<?php if($componente->com_tipo_componente == 4): ?>
												On Condition
												<?php endif; ?>
												
												<?php if($componente->com_tipo_componente == 5): ?>
												Condition Monitoring
												<?php endif; ?>
											</h4>
											<h4>
												<span class="text-info">MANTO. PROGRAMADO:</span> 
												<?php if($componente->com_principal): ?>
												SI
												<?php else: ?>
												NO
												<?php endif; ?>
											</h4>
											<h4>
												<span class="text-info">TOLERANCIA MAX.:</span> <?php echo e($mantenimiento->cma_horas_cota_max); ?> [HRS]
											</h4>        
										</div>
									</div>
								</div>
		
								</div>
	

								<form id="form-nuevo-inspeccion" action="<?php echo e(url('inspecciones')); ?>" method="POST">
								  <?php echo csrf_field(); ?>
								  <section id="seccion-datos-generales">
									<div class="row">
										<div class="col-md-6 offset-md-3">
											<div class="row">
												<div class="col-md-12">
													<div class="form-group">
															<label class="label-blue label-block" for="">
															Nombre o titulo de la inspeccion:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el nombre de la inspeccion"></i>
															</label>
														<input required type="text" value="<?php echo e(old('ins_nombre')); ?>" class="form-control <?php $__errorArgs = ['ins_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ins_nombre" id="ins_nombre" placeholder="Nombre o titulo inspeccion">
														<?php $__errorArgs = ['ins_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-12">
													<div class="form-group">
															<label class="label-blue label-block" for="">
															Descripcion de la inspeccion:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer la descripcion de la inspeccion"></i>
															</label>
														<textarea required class="form-control <?php $__errorArgs = ['uor_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ins_descripcion" id="ins_descripcion" cols="30" rows="10"><?php echo e(old('uor_nombre')); ?></textarea>
														<?php $__errorArgs = ['ins_descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>

											</div>
											<div class="row">
												<div class="col-md-6">
													<input type="hidden" name="cma_id" id="cma_id" value="<?php echo e($mantenimiento->cma_id); ?>">
													<input type="hidden" name="sec_id" id="sec_id" value="<?php echo e($servicio->sec_id); ?>">
													<button type="submit" class="btn btn-info">
															<i class="fa fa-save"></i>
															Guardar
													</button>
												</div>
											</div>

										</div>
									</div>

								  </section>


								  
								</form>
							</div>
						</div>
					</div>
				</div>

				<!-- fin card  -->

			</div>
		</div>
	</div>

<script>
$(function(){

});	


	</script>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.autenticado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TESIS - PROYECTOS - CONTRATOS\sma\sma-web\resources\views/inspecciones/form_nueva_inspeccion_componente.blade.php ENDPATH**/ ?>