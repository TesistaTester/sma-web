
<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div class="col-md-10 content-pane">
    <h3 class="title-header" style="text-transform: uppercase;">
        <i class="fa fa-wrench"></i>
        <?php echo e($titulo); ?>

        <a href="<?php echo e(url('ordenes/nuevo')); ?>" class="btn btn-sm btn-info float-right" style="margin-left:10px;"><i class="fa fa-plus"></i> NUEVA ORDEN DE TRABAJO</a>
    </h3>
    <div class="row">
        <div class="col-12">
                <!-- inicio card  -->
                <div class="card card-stat">
                    <div class="card-body">
                        <?php if($ordenes->count() == 0): ?>
                        <div class="alert alert-info">
                            <div class="media">
                                <img src="<?php echo e(asset('img/alert-info.png')); ?>" class="align-self-center mr-3" alt="...">
                                <div class="media-body">
                                    <h5 class="mt-0">Nota.-</h5>
                                    <p>
                                        NO se tiene ordenes registrados hasta el momento.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="table-responsive">
                          <table class="table table-bordered tabla-datos">
                            <thead>
                            <tr style="font-size:15px; text-align:center;">
                                <th>MATRICULA</th>
                                <th>NRO ORDEN</th>
                                <th>HORAS</th>
                                <th>CICLOS</th>
                                <th>TIPO</th>
                                <th># ACTIVIDADES</th>
                                <th>% AVANCE</th>
                                <th>OPCION</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>                                
                                <td class="text-center">
                                    <?php echo e($item->ort_matricula); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($item->ort_cite); ?>

                                </td>
                                <td class="text-center">
                                <?php echo e(intdiv($item->ort_tiempo_total_aeronave, 60)); ?>:<?php echo e((int)($item->ort_tiempo_total_aeronave)%60); ?>

                                </td>
                                <td class="text-center">
                                <?php echo e(($item->ort_ciclos_total_aeronave%60)); ?>

                                </td>
                                <td class="text-center">
                                    <?php if($item->ort_tipo == 1): ?>
                                    NORMAL
                                    <?php endif; ?>
                                    <?php if($item->ort_tipo == 2): ?>
                                    NO RUTINARIA
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php echo e($item->tarjetas_planificadas->count()); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($item->ort_avance); ?>%
                                    <br>
                                    <?php if($item->ort_avance == 100): ?>
                                        <?php if($item->ort_documento_ruta == ""): ?>
                                        <small>&laquo;Digital no cargado&raquo;</small>
                                        <?php else: ?>
                                        <small>
                                          <?php if(config('wop.disco') == 'public'): ?>
                                          <a class="btn btn-sm btn-link" target="_blank" href="<?php echo e(asset('storage/'.$item->ort_documento_ruta)); ?>">
                                          <?php else: ?>    
                                          <a class="btn btn-sm btn-link" target="_blank" href="<?php echo e(Storage::disk('gcs')->temporaryUrl($item->ort_documento_ruta,  now()->addMinutes(10))); ?>">
                                          <?php endif; ?>  
                                                <i class="fa fa-download"></i>
                                                Ver archivo
                                            </a>
                                        </small>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        OPCION
                                      </button>
                                      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                                        <?php if(config('wop.disco') == 'public'): ?>
                                        <a class="dropdown-item btn-imprimir-item" data-id="<?php echo e(Crypt::encryptString($item->ort_id)); ?>" data-descripcion="<?php echo e($item->ort_cite); ?>" data-toggle="modal" data-target="#modal-imprimir-orden" data-tarjeta-link="<?php echo e(asset('storage/'.$item->tarjeta->tar_digitalizado)); ?>" href="#"><i class="fa fa-print"></i> Imprimir orden</a>
                                        <?php else: ?>    
                                        <a class="dropdown-item btn-imprimir-item" data-id="<?php echo e(Crypt::encryptString($item->ort_id)); ?>" data-descripcion="<?php echo e($item->ort_cite); ?>" data-toggle="modal" data-target="#modal-imprimir-orden" data-tarjeta-link="<?php echo e(Storage::disk(config('wop.disco'))->temporaryUrl($item->tarjeta->tar_digitalizado,  now()->addMinutes(10))); ?>" href="#"><i class="fa fa-print"></i> Imprimir orden</a>
                                        <?php endif; ?>    
                                        <?php if($item->ort_avance < 100): ?>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item btn-eliminar-item" data-id="<?php echo e($item->ort_id); ?>" data-descripcion="<?php echo e($item->ort_cite); ?>" data-toggle="modal" data-target="#modal-eliminar-orden" href="#"><i class="fa fa-trash"></i> Anular orden</a>
                                        <?php endif; ?>
                                        <?php if($item->ort_avance == 100): ?>
                                            
                                            <a class="dropdown-item btn-subir-orden" data-id="<?php echo e($item->ort_id); ?>" data-descripcion="<?php echo e($item->ort_cite); ?>" data-toggle="modal" data-target="#modal-subir-orden" href="#"><i class="fa fa-upload"></i> Subir digitalizado</a>
                                            
                                        <?php endif; ?>
                                      </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- fin card  -->
        </div>
    </div>
</div>



<div class="modal fade" id="modal-imprimir-orden" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#eee;">
          <h5 class="modal-title text-primary">
              <i class="fa fa-print"></i>
              Imprimir orden de trabajo
            </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <div class="box-data-xtra">
                <h5>
                    <span class="text-success">DESCRIPCION: </span>
                    <span id="txt-descripcion-imprimir"></span><br>
                </h5>
            </div>
            <hr>
            <div class="row text-center">
              <div class="col-md-10 offset-md-1">
                <a target="_blank" id="link-1" class="btn btn-sm btn-info btn-block" data-simple-action="<?php echo e(url('ordenes/print1/')); ?>" href="<?php echo e(url('ordenes/print1/')); ?>"> <i class="fa fa-print"></i> Imprimir Orden (pág. 1)</a>
                <div style="margin-bottom:7px;"></div>
                <a target="_blank" id="link-2" class="btn btn-sm btn-info btn-block" href="<?php echo e(asset('pdf/reverso_ot_tab-ea-nuevo.pdf')); ?>"> <i class="fa fa-print"></i> Imprimir Reverso (pag. 2)</a>
                <div style="margin-bottom:7px;"></div>
                <a target="_blank" id="link-3" class="btn btn-sm btn-info btn-block" data-simple-action="<?php echo e(url('ordenes/print3/')); ?>" href="<?php echo e(url('ordenes/print3/')); ?>"> <i class="fa fa-print"></i> Imprimir Designacion de Personal (pág. 3)</a>
                <div style="margin-bottom:7px;"></div>
                <a target="_blank" id="link-4" class="btn btn-sm btn-info btn-block" href=""> <i class="fa fa-print"></i> Imprimir Tarjeta de Inspeccion</a>
              </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Cerrar</button>
        </div>
      </div>
    </div>
  </div>




<div class="modal fade" id="modal-eliminar-orden" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#eee;">
          <h5 class="modal-title text-primary">
              <i class="fa fa-trash"></i>
              Eliminar item
            </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <div class="box-data-xtra">
                <h5>
                    <span class="text-success">DESCRIPCION: </span>
                    <span id="txt-descripcion"></span><br>
                </h5>
            </div>
            <div class="alert alert-danger">
                <div class="media">
                    <img src="<?php echo e(asset('img/alert-danger.png')); ?>" class="align-self-center mr-3" alt="...">
                    <div class="media-body">
                        <h5 class="mt-0">Cuidado.-</h5>
                        <p>
                            <small>
                                Esta operación es irreversible y se eliminarán todos los registros del personal y actividades planificadas asociadas a la orden de trabajo.
                            </small>
                            <br>
                            ¿Está seguro que desea eliminar éste registro?
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Cerrar</button>
          <form id="form-eliminar-item" action="<?php echo e(url('ordenes')); ?>" data-simple-action="<?php echo e(url('ordenes')); ?>" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> Si, eliminar</button>
          </form>
        </div>
      </div>
    </div>
  </div>



<div class="modal fade" id="modal-subir-orden" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#eee;">
          <h5 class="modal-title text-primary">
              <i class="fa fa-upload"></i>
              Subir orden digitalizada
            </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form id="form-subir-orden" enctype="multipart/form-data" action="<?php echo e(url('ordenes/subir_digital')); ?>" data-simple-action="<?php echo e(url('ordenes/subir_digital')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="box-data-xtra">
                <h5>
                    <span class="text-success">ORDEN: </span>
                    <span id="txt-descripcion-subir"></span><br>
                </h5>
            </div>
            <br>
			<div class="form-group">
				<label class="label-blue label-block" for="">
				Cargar orden digitalizada en PDF:
				<span class="text-danger">*</span>
				<i class="fa fa-question-circle float-right" title="Establecer el archivo digitalizado de la orden"></i>
				</label>
				<input required type="file" value="<?php echo e(old('ort_documento_ruta')); ?>" class="form-control <?php $__errorArgs = ['ort_documento_ruta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ort_documento_ruta" id="ort_documento_ruta" accept=".pdf">
				<?php $__errorArgs = ['ort_documento_ruta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="invalid-feedback">
					<?php echo e($message); ?>

				</div>											
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>            
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Cerrar</button>
            <button type="submit" class="btn btn-info"><i class="fa fa-upload"></i> Subir archivo</button>
        </div>
        </form>
      </div>
    </div>
  </div>
  


<script type="text/javascript">
$(function(){
    /*
    -------------------------------------------------------------
    * CONFIGURACION DATA TABLES
    -------------------------------------------------------------
    */
    $('.tabla-datos').DataTable({"language":{url: '<?php echo e(asset('js/datatables-lang-es.json')); ?>'}, "order": [[ 1, "desc" ]]});

    /*
    --------------------------------------------------------------
    ELIMINAR ITEM
    --------------------------------------------------------------
    */
    $('.btn-imprimir-item').click(function(){
       let usu_id = $(this).attr('data-id');
       let usu_nombre = $(this).attr('data-descripcion');
       let tarjeta_link = $(this).attr('data-tarjeta-link');
       $('#txt-descripcion-imprimir').html(usu_nombre);
       //generate links
       action1 = $('#link-1').attr('data-simple-action');
    //    action2 = $('#link-2').attr('data-simple-action');
       action3 = $('#link-3').attr('data-simple-action');
       action1 = action1+'/'+usu_id;
    //    action2 = action2+'/'+usu_id;
       action3 = action3+'/'+usu_id;
       $('#link-1').attr('href',action1);
    //    $('#link-2').attr('href',action2);
       $('#link-3').attr('href',action3);
       $('#link-4').attr('href',tarjeta_link);
   });
    $('.btn-eliminar-item').click(function(){
       let usu_id = $(this).attr('data-id');
       let usu_nombre = $(this).attr('data-descripcion');
       $('#txt-descripcion').html(usu_nombre);
       //form data
       action = $('#form-eliminar-item').attr('data-simple-action');
       action = action+'/'+usu_id;
       $('#form-eliminar-item').attr('action',action);
   });

   $('.btn-subir-orden').click(function(){
       let usu_id = $(this).attr('data-id');
       let usu_nombre = $(this).attr('data-descripcion');
       $('#txt-descripcion-subir').html(usu_nombre);
       //form data
       action = $('#form-subir-orden').attr('data-simple-action');
       action = action+'/'+usu_id;
       $('#form-subir-orden').attr('action',action);
   });


});


</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.autenticado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TESIS - PROYECTOS - CONTRATOS\sma\sma-web\resources\views/ordenes/lista_ordenes.blade.php ENDPATH**/ ?>