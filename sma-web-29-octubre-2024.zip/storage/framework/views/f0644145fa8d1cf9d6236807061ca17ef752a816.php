<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('titulo'); ?> - <?php echo e(env('APP_NAME')); ?></title>
    
    <link rel="shortcut icon" href="<?php echo e(url('img/favicon.ico')); ?>" type="image/x-icon">
	<link rel="icon" href="<?php echo e(url('img/favicon.ico')); ?>" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/ext.styles.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/font-awesome.min.css')); ?>">
	<style>
        body{
          background-image: url('<?php echo e(asset('img/bg_login_01.png')); ?>');
          background-position: center center;
          background-repeat: no-repeat;
          background-attachment: fixed;
          background-size: cover;
        }
    </style>
</head>
<body>
    
    <?php echo $__env->yieldContent('contenido'); ?>        
    
    <script src="<?php echo e(url('js/jquery36.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
    <script>
        $(function(){
            $('.login-box').hide();
            $('.login-box').fadeIn(2000);
        });
    </script>
</body>
</html><?php /**PATH D:\TESIS - PROYECTOS - CONTRATOS\sma\sma-web\resources\views/layouts/noautenticado.blade.php ENDPATH**/ ?>