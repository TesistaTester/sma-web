
<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div class="col-md-10 content-pane">
    <h3 class="title-header" style="text-transform: uppercase;">
        <i class="fa fa-home"></i>
        <?php echo e($titulo); ?>

    </h3>
    <div class="row">
        <div class="col-12">
                <!-- inicio card  -->
                <div class="card card-stat">
                    <div class="card-body">
                            <div class="row">
                              <div class="col-md-3">
                                <div class="box-result">
                                    <h1><?php echo e($grupos->count()); ?></h1>
                                    GRUPOS REGISTRADOS
                                </div>
                              </div>
                              <div class="col-md-3">
                                  <div class="box-result">
                                      <h1><?php echo e($aeronaves->count()); ?></h1>
                                      AERONAVES REGISTRADAS
                                  </div>
                                </div>
                                <div class="col-md-3">
                                  <div class="box-result">
                                      <h1><?php echo e($componentes->count()); ?></h1>
                                      COMPONENTES CONTROLADOS
                                  </div>
                                </div>
                                <div class="col-md-3">
                                  <div class="box-result">
                                      <h1><?php echo e($registros_vuelo->count()); ?></h1>
                                      REGISTROS DE HORAS VUELO
                                  </div>
                                </div>
                            </div>
                            <div class="row">
                              <div class="col-md-3">
                                <div class="box-result">
                                    <?php
                                      $cont_inspecciones_abiertas = 0;
                                      foreach($inspecciones as $item){
                                        if($item->ordenes->count() > 0){
                                          $cont_inspecciones_abiertas++;
                                        }
                                      }
                                    ?>
                                    <h1><?php echo e($cont_inspecciones_abiertas); ?></h1>
                                    INSPECCIONES EN PROCESO
                                </div>
                              </div>
                              <div class="col-md-3">
                                  <div class="box-result">
                                      <h1><?php echo e($ordenes->count()); ?></h1>
                                      TOTAL ORDENES
                                  </div>
                                </div>
                                <div class="col-md-3">
                                  <div class="box-result">
                                      <h1><?php echo e($ordenes->where('ort_avance', '<', 100)->count()); ?></h1>
                                      ORDENES ABIERTAS
                                  </div>
                                </div>
                                <div class="col-md-3">
                                  <div class="box-result">
                                      <h1><?php echo e($ordenes->where('ort_avance', 100)->count()); ?></h1>
                                      ORDENES CONCLUIDAS
                                  </div>
                                </div>
                            </div>
                            <div class="row">                            
                              <div class="col-md-3">
                                  <div class="box-result">
                                      <h1><?php echo e($tarjetas->count()); ?></h1>
                                      TARJETAS PLANIFICADAS
                                  </div>
                              </div>
                              <div class="col-md-3">
                                <div class="box-result">
                                    <h1><?php echo e($tarjetas->where('tap_estado', 0)->count()); ?></h1>
                                    TARJETAS EN ESPERA
                                </div>
                              </div>
                              <div class="col-md-3">
                                <div class="box-result">
                                    <h1><?php echo e($tarjetas->where('tap_estado', 1)->count()); ?></h1>
                                    TARJETAS EN PROCESO
                                </div>
                              </div>
                              <div class="col-md-3">
                                <div class="box-result">
                                    <h1><?php echo e($tarjetas->where('tap_estado', 2)->count()); ?></h1>
                                    TARJETAS TERMINADAS
                                </div>
                              </div>
                          </div>
                          

                          </div>
                            <hr>
                            <hr>
                            <div class="row">
                            </div>
    
                    </div>
                </div>
                <!-- fin card  -->



        </div>
    </div>
</div>




<script type="text/javascript">
$(function(){


});


</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.autenticado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TESIS - PROYECTOS - CONTRATOS\sma\sma-web\resources\views/dashboard/detalle_tablero.blade.php ENDPATH**/ ?>