
<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div class="col-md-10 content-pane">
    <h3 class="title-header" style="text-transform: uppercase;">
        <i class="fa fa-line-chart"></i>
        <?php echo e($titulo); ?>

    </h3>
    <div class="row">
        <div class="col-12">
                <!-- inicio card  -->
                <div class="card card-stat">
                    <div class="card-body">
                        <?php if($ordenes->count() == 0): ?>
                        <div class="alert alert-info">
                            <div class="media">
                                <img src="<?php echo e(asset('img/alert-info.png')); ?>" class="align-self-center mr-3" alt="...">
                                <div class="media-body">
                                    <h5 class="mt-0">Nota.-</h5>
                                    <p>
                                        NO se tiene ordenes registrados hasta el momento.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-bordered tabla-datos">
                                <thead>
                                <tr style="font-size:15px; text-align:center;">
                                    <th>MATRICULA</th>
                                    <th>NRO ORDEN</th>
                                    <th>NRO TARJETA</th>
                                    <th>TIPO</th>
                                    <th># ACTIVIDADES</th>
                                    <th>% AVANCE</th>
                                    <th>OPCION</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->ort_avance < 20): ?>
                                    <tr>                                
                                    <?php endif; ?>
                                    <?php if($item->ort_avance >= 20 && $item->ort_avance < 40): ?>
                                    <tr class="bg-avance-30">                                
                                    <?php endif; ?>
                                    <?php if($item->ort_avance >= 40 && $item->ort_avance < 60): ?>
                                    <tr class="bg-avance-50">                                
                                    <?php endif; ?>
                                    <?php if($item->ort_avance >= 60 && $item->ort_avance < 80): ?>
                                    <tr class="bg-avance-70">                                
                                    <?php endif; ?>
                                    <?php if($item->ort_avance >= 80 && $item->ort_avance <= 100): ?>
                                    <tr class="bg-avance-90">                                
                                    <?php endif; ?>
                                    <td class="text-center">
                                        <?php echo e($item->ort_matricula); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($item->ort_cite); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($item->tarjeta->tar_numero); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php if($item->ort_tipo == 1): ?>
                                        NORMAL
                                        <?php endif; ?>
                                        <?php if($item->ort_tipo == 2): ?>
                                        NO RUTINARIA
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php echo e($item->tarjetas_planificadas->count()); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($item->ort_avance); ?>%
                                    </td>
                                    <td>
                                        <a class="btn btn-secondary" href="<?php echo e(url('seguimientos/'.Crypt::encryptString($item->ort_id))); ?>"><i class="fa fa-th"></i> Ver tablero</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>    
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- fin card  -->
        </div>
    </div>
</div>




<script type="text/javascript">
$(function(){
    /*
    -------------------------------------------------------------
    * CONFIGURACION DATA TABLES
    -------------------------------------------------------------
    */
    $('.tabla-datos').DataTable({"language":{url: '<?php echo e(asset('js/datatables-lang-es.json')); ?>'}, "order": [[ 1, "desc" ]]});

    /*
    --------------------------------------------------------------
    ELIMINAR ITEM
    --------------------------------------------------------------
    */
    $('.btn-eliminar-item').click(function(){
       let usu_id = $(this).attr('data-id');
       let usu_nombre = $(this).attr('data-descripcion');
       $('#txt-descripcion').html(usu_nombre);
       //form data
       action = $('#form-eliminar-item').attr('data-simple-action');
       action = action+'/'+usu_id;
       $('#form-eliminar-item').attr('action',action);
   });



});


</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.autenticado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TESIS - PROYECTOS - CONTRATOS\sma\sma-web\resources\views/seguimientos/lista_ordenes.blade.php ENDPATH**/ ?>