<?php 

return [
    //configuracion de GCS
    'disco' => 'gcs',//gcs google cloud storage - public para disco local
    'modelo' => 'L 382C-72D',
    'matricula' => 'FAB-81',
    'serial_number' => 'LAC-4759',
    'total_horas' => '1801712',
    'total_landings' => '18040',
    'apu_sn' => '',
    'eti' => '',
    'ref_manual' => 'T.O. SMP515-C-5/119 TARJETAS',
    'localidad' => 'EL ALTO',
    //JEFES ORDENES DE TRABAJO
    // 'inspector_mantenimiento' => 'Sof.Inc.Tec.Alvaro Alba Poma',
    // 'supervisor_calidad' => 'Sof.2do.DESA.Grover Gutierrez Cahuaya',
    'jefe_control_calidad' => 'SOF. 1RO. DESA. ELMER COCARICO MAYTA',
    'jefe_mantenimiento' => 'SOF. 1RO. DESA. LIMBER YUJRA CH.',
    'jefe_aeronavegabilidad' => 'SOF.MY.DESA. ABEL CALLE PAZ',
];

?>



